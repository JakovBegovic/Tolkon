#include <stdio.h>
 #include <string.h>
 #include <time.h>
 #include "gui/gui.h"
 #include "lvgl.h"
 #include "ui.h"
 #include "ultrasonic.h"
 #include "sound.h"
 #include "temp.h"
 #include "wifi_controller.h"
 #include "driver/gpio.h"
 #include "sht3x.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define UART_STACK_SIZE             (4096)
#define INIT_DELAY    500
#define SLEEP_DELAY   5000


static const char *MAIN_TAG = "main";
static const char *SENSORS_TAG = "sensors";

char scale = SCALE_CELCIUS;
float temperature = 0.0;
float humidity = 0.0;

void sensors_task(void *arg) {
    i2c_config_t i2c_config = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_MASTER_SDA,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_io_num = I2C_MASTER_SCL,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_MASTER_FREQ_HZ
    };

    ESP_ERROR_CHECK(i2c_param_config(I2C_MASTER_NUM, &i2c_config));
    ESP_ERROR_CHECK(i2c_driver_install(I2C_MASTER_NUM, i2c_config.mode,
                    I2C_MASTER_RX_BUF_DISABLE, I2C_MASTER_TX_BUF_DISABLE, 0));

    esp_log_level_set(SENSORS_TAG, ESP_LOG_INFO);

    #if defined(SENSORS_SCALE_F)
    scale = SCALE_FAHRENHEIT;
    #elif defined(SENSORS_SCALE_K)
    scale = SCALE_KELVIN;
    #endif

    vTaskDelay(INIT_DELAY / portTICK_PERIOD_MS);

    for(;;) {
        sht3x_start_periodic_measurement();

        sht3x_sensors_values_t sensors_values = {
            .temperature = 0x00,
            .humidity = 0x00
        };
        vTaskDelay(INIT_DELAY / portTICK_PERIOD_MS);

        if(sht3x_read_measurement(&sensors_values) != ESP_OK) {
            ESP_LOGE(SENSORS_TAG, "Sensors read measurement error!");
        }
        vTaskDelay(INIT_DELAY / portTICK_PERIOD_MS);

        float temperature = sensors_values.temperature;
        float humidity = sensors_values.humidity;

        #if defined(SENSORS_SCALE_F)
        temperature = FAHRENHEIT(temperature);
        #elif defined(SENSORS_SCALE_K)
        temperature = KELVIN(temperature);
        #endif

        ESP_LOG_BUFFER_HEX_LEVEL(SENSORS_TAG, &sensors_values, sizeof(sensors_values), ESP_LOG_DEBUG);

        sht3x_stop_periodic_measurement();

        ESP_LOGI(SENSORS_TAG, "Temperature %2.1f °%c - Humidity %2.1f%%", temperature, scale, humidity);
        vTaskDelay(SLEEP_DELAY / portTICK_PERIOD_MS);
    }
}



 
 char strftime_buf[ 64 ];
 extern void temp_task(void *pvParameters);
 static void time_update_task(void *pvParameters) {
    struct tm timeinfo;
    char strftime_buf[64];

    while (1) {
        time_t now;
        time(&now);
        localtime_r(&now, &timeinfo);

        strftime(strftime_buf, sizeof(strftime_buf), "%a %d %B %H:%M", &timeinfo);
        lv_label_set_text(ui_Time, strftime_buf);

        // ✅ ključno: ne blokiraj CPU
        vTaskDelay(pdMS_TO_TICKS(60000));
    }
}


 
 void app_main(void)
{
    gpio_set_direction(GPIO_NUM_17, GPIO_MODE_OUTPUT);
    gpio_set_level(GPIO_NUM_17, 1);
    wifi_init_sta();
    gui_init();
    setup_time();
    ultrasonic_init();
    sound_init();
    esp_log_level_set(MAIN_TAG, ESP_LOG_INFO);

    // Pokreni task za ažuriranje vremena
    xTaskCreate(time_update_task, "time_update_task", 4096, NULL, 5, NULL);
    xTaskCreate(temp_task, "temp_task", 4096, NULL, 5, NULL);
    xTaskCreate(sensors_task, "sensors_task", UART_STACK_SIZE, NULL, configMAX_PRIORITIES-9, NULL);
}