#ifndef TEMP_H
#define TEMP_H

#ifdef __cplusplus
extern "C" {
#endif

void temp_task(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif // TEMP_H
