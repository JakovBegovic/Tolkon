#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "lvgl.h"
#include "ui.h"
#include "sht3x.h"
#include <stdlib.h>
#include "driver/i2c.h"


#define TAG "TEMP_SENSOR"

static esp_err_t i2c_master_init(void)
{
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = I2C_MASTER_SDA,
        .scl_io_num = I2C_MASTER_SCL,
        .sda_pullup_en = GPIO_PULLUP_ENABLE,
        .scl_pullup_en = GPIO_PULLUP_ENABLE,
        .master.clk_speed = I2C_MASTER_FREQ_HZ,
    };

    esp_err_t err = i2c_param_config(I2C_MASTER_NUM, &conf);
    if (err != ESP_OK) return err;

    return i2c_driver_install(I2C_MASTER_NUM, conf.mode, 0, 0, 0);
}


static void update_temp_label_cb(void *text)
{
    lv_label_set_text(ui_temp, (const char *)text);
    free(text);
}

void temp_task(void *pvParameters)
{
    if (i2c_master_init() != ESP_OK) {
        ESP_LOGE(TAG, "Failed to init I2C");
        vTaskDelete(NULL);
    }

    sht3x_sensors_values_t sensor_data;

    while (1) {
        if (sht3x_read_measurement(&sensor_data) == ESP_OK) {
            ESP_LOGI(TAG, "Temperature: %.2f °C, Humidity: %.2f %%", sensor_data.temperature, sensor_data.humidity);

            char buf[32];
            snprintf(buf, sizeof(buf), "%.2f °C", sensor_data.temperature);

            char *text = strdup(buf);
            if (text) {
                lv_async_call(update_temp_label_cb, text);
            }
        } else {
            ESP_LOGE(TAG, "SHT3x read failed");
        }

        vTaskDelay(pdMS_TO_TICKS(2000));
    }
}